<div class="container">
  <div class="row">
    <div class="col">
      <hr />
      <p>&copy Copyright Ecommerce Prodi Sistem Informasi</p>
    </div>
  </div>
</div>